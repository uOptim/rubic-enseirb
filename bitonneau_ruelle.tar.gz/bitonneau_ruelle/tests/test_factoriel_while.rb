# Cet exemple illustre le calcul de 5! à l'aide d'une boucle while

a = 1
i = 2

while i < 6
	a = a*i
	i = i + 1
end

puts a
