# Test devant afficher un warning à la compilation sur la modification de
# constantes.

Aa = 10
Aa = 30
puts Aa
