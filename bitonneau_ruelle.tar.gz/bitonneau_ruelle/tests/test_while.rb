b = 5

while b > 0
	b = b - 1
	puts b
end
