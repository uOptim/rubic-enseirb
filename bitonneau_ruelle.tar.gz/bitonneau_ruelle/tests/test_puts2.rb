a = 3
puts a
