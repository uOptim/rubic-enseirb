if true then
	puts 1
else
	puts 0
end
