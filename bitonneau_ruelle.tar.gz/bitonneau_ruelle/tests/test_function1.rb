def f()
	return 1
end

def g()
	puts 2
end

# should print 1
puts f()
