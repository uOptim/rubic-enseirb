puts 1 * 3
