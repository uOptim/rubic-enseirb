# Cet exemple illustre le calcul de 5! à l'aide de la boucle for

a = 1

for i in 2 .. 5
	a = a*i
end

puts a
