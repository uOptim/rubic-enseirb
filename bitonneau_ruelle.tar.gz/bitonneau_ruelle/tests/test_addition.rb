puts 1 + 3
puts 1.3 + 5
puts 4.2 + 6.5
