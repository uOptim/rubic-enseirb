puts 1 / 3
puts 1. / 3
