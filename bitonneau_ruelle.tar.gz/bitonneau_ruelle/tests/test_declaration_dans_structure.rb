# Cet exemple illustre la possibilité de déclarer des variables à l'intérieur
# de structures de contrôle

if true then
	a = 1
else
	a = 0
end

puts a
