# Cet exemple illustre la conversion de nombres vers les booléens et le calcul
# de 5!

b = 5
a = 1

while b
	a = a*b
	b = b - 1
end

puts a
