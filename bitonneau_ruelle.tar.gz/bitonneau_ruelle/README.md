# Rubic

A compiler for Rubic.

Authors: Benoît Ruelle
         David  Bitonneau

The compiler can be built by running:
$make

Test files can be built by our compiler with:
$ make tests
If there is a problem compiling a test file, compilation will stop and will
not be performed for the following tests.

Afterwards, compiled test files can be run with:
$ make runtests
